﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ado.netnew
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        employeeDAL objemployeeDAL;
        

        private void Btnsave_Click(object sender, RoutedEventArgs e)
        {

            insertemployee();
        }

        private void Btnupdate_Click(object sender, RoutedEventArgs e)
        {
            updateemployee();
        }

        private void Btnsearch_Click(object sender, RoutedEventArgs e)
        {
            searchemployee();
        }

        private void Btngetlist_Click(object sender, RoutedEventArgs e)
        {
            getemployees();
        }

        private void Btnclear_Click(object sender, RoutedEventArgs e)
        {
            clear();
        }

        private void Btndelete_Click(object sender, RoutedEventArgs e)
        {
            deleteemployee();
        }
        private void insertemployee()
        {
            int id;
            string name;
            int designation;
            int department;
            id = Convert.ToInt32(txtid.Text);
            name = txtname.Text;
            designation = Convert.ToInt32(cbdesignation.SelectedValue);
            department = Convert.ToInt32(cbdepartment.SelectedValue);
            employee objemployee = new employee();
            objemployee.id = id;
            objemployee.name = name;
            objemployee.desg = designation;
            objemployee.dept = department;
            bool dataadded = objemployeeDAL.Insertemployee(objemployee);

            if (dataadded == true)
            {
                MessageBox.Show("data added successfully");
            }
            else
            {
                MessageBox.Show("data couldn't be added");
            }





        }
        private void updateemployee()
        {
            int id;
            string name;
            int designation;
            int department;
            id = Convert.ToInt32(txtid.Text);
            name = txtname.Text;
            designation = Convert.ToInt32(cbdesignation.SelectedValue);
            department = Convert.ToInt32(cbdepartment.SelectedValue);
            employee objemployee = new employee();
            objemployee.id = id;
            objemployee.name = name;
            objemployee.desg = designation;
            objemployee.dept = department;
            bool dataupdated = objemployeeDAL.Updateemployee(objemployee);

            if (dataupdated == true)
            {
                MessageBox.Show("data updated successfully");
            }
            else
            {
                MessageBox.Show("data couldn't be updated");
            }
        }
        private void deleteemployee()
        {
            int id;
            id = Convert.ToInt32(txtid.Text);
            bool datadeleted = objemployeeDAL.Deleteemployee(id);
            if (datadeleted == true)
            {
                MessageBox.Show("data deleted successfully");

            }
            else
            {
                MessageBox.Show("data coudn't be deleted");
            }

        }
        private void searchemployee()
        {
            int id;
            id = Convert.ToInt32(txtid.Text);
            employee objemployee = objemployeeDAL.Searchemployee(id);
            if (objemployee != null)
            {
                txtname.Text = objemployee.name;
                cbdesignation.SelectedValue = objemployee.desg;
                cbdepartment.SelectedValue = objemployee.dept;

            }
            else
            {
                MessageBox.Show("data not found for the given id");
            }
        }
        private void getemployees()
        {
            DataTable objDT = objemployeeDAL.getemployees();
            dgemployeedetails.ItemsSource = objDT.DefaultView;

        }
        private void getdesignations()
        {
            DataTable objDT = objemployeeDAL.getdesignations();
            cbdesignation.ItemsSource = objDT.DefaultView;
            cbdesignation.DisplayMemberPath = objDT.Columns[1].ToString();
            cbdesignation.SelectedValuePath = objDT.Columns[0].ToString();
        }
        private void getdepartments()
        {
            DataTable objDT = objemployeeDAL.getdepartments();
            cbdepartment.ItemsSource = objDT.DefaultView;
            cbdepartment.DisplayMemberPath = objDT.Columns[1].ToString();
            cbdepartment.SelectedValuePath = objDT.Columns[0].ToString();
        }
        private void clear()
        {
            txtid.Clear();
            txtname.Clear();
            cbdepartment.SelectedIndex = -1;
            cbdesignation.SelectedIndex = -1;

        }

        private void Window_Loaded_1(object sender, RoutedEventArgs e)
        {

            objemployeeDAL = new employeeDAL();
            getdepartments();
            getdesignations();
        }
    }
}
