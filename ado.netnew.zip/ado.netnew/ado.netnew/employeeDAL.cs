﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;



namespace ado.netnew
{
    public class employeeDAL
    {
        public bool Insertemployee(employee objemployee)
        {
            bool datainserted = false;
            SqlConnection objCon = new SqlConnection(@"server=ndamssql\sqlilearn;database=Training_19Sep19_Pune;uid=sqluser;pwd=sqluser");
            SqlCommand objCom = new SqlCommand(
                "insert into [46008587].employee values("
                + objemployee.id + ", '"
                + objemployee.name + "',"
               + objemployee.desg + ","
               + objemployee.dept + ")", objCon
                );
            objCon.Open();
            int noOfRowsAffected = objCom.ExecuteNonQuery();
            if (noOfRowsAffected > 0)
            {
                datainserted = true;
            }
            objCon.Close();
            return datainserted;

        }
        public bool Updateemployee(employee objemployee)
        {
            bool dataupdated = false;
            SqlConnection objCon = new SqlConnection(@"server=ndamssql\sqlilearn;database=Training_19Sep19_Pune;uid=sqluser;pwd=sqluser");
            SqlCommand objCom = new SqlCommand(
                "update [46008587].employee set name='" + objemployee.name
                + "'designation=" + objemployee.desg
                + ",department=" + objemployee.dept
                + "where id=" + objemployee.id, objCon
                );
            objCon.Open();
            int noOfRowsAffected = objCom.ExecuteNonQuery();
            if (noOfRowsAffected > 0)
            {
                dataupdated = true;
            }
            objCon.Close();
            return dataupdated;
        }
        public bool Deleteemployee(int id)
        {
            bool datadeleted = false;
            SqlConnection objCon = new SqlConnection(@"server=ndamssql\sqlilearn;database=Training_19Sep19_Pune;uid=sqluser;pwd=sqluser");
            SqlCommand objCom = new SqlCommand(
                "delete [46008587].employee where id=" + id, objCon
                );
            objCon.Open();
            int noOfRowsAffected = objCom.ExecuteNonQuery();
            if (noOfRowsAffected > 0)
            {
                datadeleted = true;
            }
            objCon.Close();
            return datadeleted;

        }
        public employee Searchemployee(int id)
        {
            SqlConnection objCon = new SqlConnection(@"server=ndamssql\sqlilearn;database=Training_19Sep19_Pune;uid=sqluser;pwd=sqluser");
            SqlCommand objCom = new SqlCommand(
                "select *from [46008587].employee where id=" + id, objCon
                );
            objCon.Open();
            SqlDataReader objDR = objCom.ExecuteReader();
            employee objemployee = null;
            if (objDR.HasRows)
            {
                objDR.Read();
                objemployee = new employee();
                objemployee.id = Convert.ToInt32(objDR[0]);
                objemployee.name = objDR[1].ToString();
                objemployee.desg = Convert.ToInt32(objDR[2]);
                objemployee.dept = Convert.ToInt32(objDR[3]);
            }
            return objemployee;

        }
        public DataTable getemployees()
        {

            SqlConnection objCon = new SqlConnection(@"server=ndamssql\sqlilearn;database=Training_19Sep19_Pune;uid=sqluser;pwd=sqluser");
            SqlCommand objCom = new SqlCommand(
                "select * from [46008587].employee", objCon
                );
            objCon.Open();
            SqlDataReader objDR = objCom.ExecuteReader();
            DataTable objDT = new DataTable();
            objDT.Load(objDR);
            objCon.Close();
            return objDT;
        }
        public DataTable getdesignations()
        {

            SqlConnection objCon = new SqlConnection(@"server=ndamssql\sqlilearn;database=Training_19Sep19_Pune;uid=sqluser;pwd=sqluser");
            SqlCommand objCom = new SqlCommand(
                "select * from [46008587].designation", objCon
                );
            objCon.Open();
            SqlDataReader objDR = objCom.ExecuteReader();
            DataTable objDT = new DataTable();
            objDT.Load(objDR);
            objCon.Close();
            return objDT;
        }
        public DataTable getdepartments()
        {

            SqlConnection objCon = new SqlConnection(@"server=ndamssql\sqlilearn;database=Training_19Sep19_Pune;uid=sqluser;pwd=sqluser");
            SqlCommand objCom = new SqlCommand(
                "select * from [46008587].department", objCon
                );
            objCon.Open();
            SqlDataReader objDR = objCom.ExecuteReader();
            DataTable objDT = new DataTable();
            objDT.Load(objDR);
            objCon.Close();
            return objDT;
        }
    }
}
