﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ENTITIES;
using EXCEPTIONS;
using BAL;
using System.Data;

namespace HRDS_withADOWPF
{
    /// <summary>
    /// Interaction logic for Mainwindow.xaml
    /// </summary>
    public partial class MainWindow: Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        
        private void BtnAddEmployee_Click(object sender, RoutedEventArgs e)
        {
            AddEmployee();
        }

        private void BtnUpdateEmployee_Click(object sender, RoutedEventArgs e)
        {
            UpdateEmployee();
        }

        private void BtnDeleteEmployee_Click(object sender, RoutedEventArgs e)
        {
            DeleteEmployee();
        }

        private void BtnSearchEmployee_Click(object sender, RoutedEventArgs e)
        {
            SearchEmployee();
        }

        private void BtnGetEmployees_Click_1(object sender, RoutedEventArgs e)
        {
            GetEmployees();

        }
        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            Clear();
        }
        
        

        private void AddEmployee()
        {
            try
            {
                int id;
                string name;
                int designationid;
                int departmentId;
                //
                bool employeeAdded;
                //
                id = Convert.ToInt32(txtId.Text);
                name = txtName.Text;
                designationid = Convert.ToInt32(cmbDesignations.SelectedValue);
                departmentId = Convert.ToInt32(cmbDepartments.SelectedValue);
                //
                Employee objEmployee = new Employee
                {
                    Id = id,
                    Name = name,
                    Designation = designationid,
                    Department = departmentId
                };
                employeeAdded = EmployeeBAL.AddEmployeeBL(objEmployee);
                if (employeeAdded == true)
                {
                    MessageBox.Show("Employee record added successfully.");
                }
                else
                {
                    MessageBox.Show("Employee record couldn't be added.");
                }
            }
            catch (EmployeeException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void UpdateEmployee()
        {
            try
            {
                int id;
                string name;
                int designationid;
                int departmentId;
                //
                bool employeeUpdated;
                //
                id = Convert.ToInt32(txtId.Text);
                name = txtName.Text;
                designationid = Convert.ToInt32(cmbDesignations.SelectedValue);
                departmentId = Convert.ToInt32(cmbDepartments.SelectedValue);
                //
                Employee objEmployee = new Employee
                {
                    Id = id,
                    Name = name,
                    Designation = designationid,
                    Department = departmentId
                };
                employeeUpdated = EmployeeBAL.UpdateEmployeeBL(objEmployee);
                if (employeeUpdated == true)
                {
                    MessageBox.Show("Employee record updated successfully.");
                }
                else
                {
                    MessageBox.Show("Employee record couldn't be updated.");
                }
            }
            catch (EmployeeException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void DeleteEmployee()
        {
            try
            {
                int id;
                //
                bool employeeDeleted;
                //
                id = Convert.ToInt32(txtId.Text);
                //
                employeeDeleted = EmployeeBAL.DeleteEmployeeBL(id);
                if (employeeDeleted == true)
                {
                    MessageBox.Show("Employee record deleted successfully.");
                }
                else
                {
                    MessageBox.Show("Employee record couldn't be deleted.");
                }
            }
            catch (EmployeeException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void SearchEmployee()
        {
            try
            {
                int id;
                //
                Employee objEmployee;
                //
                id = Convert.ToInt32(txtId.Text);
                //
                objEmployee = EmployeeBAL.SearchEmployeeBL(id);
                if (objEmployee != null)
                {
                    txtName.Text = objEmployee.Name;
                    cmbDesignations.SelectedValue = objEmployee.Designation;
                    cmbDepartments.SelectedValue = objEmployee.Department;
                }
                else
                {
                    MessageBox.Show("Employee record couldn't be found.");
                }
            }
            catch (EmployeeException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void GetEmployees()
        {
            try
            {
                List<Employee> objEmployees = EmployeeBAL.GetAllEmployeeBL();
                if (objEmployees != null)
                {
                    dgEmployees.ItemsSource = objEmployees;
                }
                else
                {
                    MessageBox.Show("No records available.");
                }
            }
            catch (EmployeeException ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
        private void GetDesignations()
        {
            try
            {
                DataTable designationList = EmployeeBAL.GetDesignationsBL();
                cmbDesignations.ItemsSource = designationList.DefaultView;
                cmbDesignations.DisplayMemberPath = designationList.Columns[1].ColumnName;
                cmbDesignations.SelectedValuePath = designationList.Columns[0].ColumnName;
            }
            catch (EmployeeException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void GetDepartments()
        {
            try
            {
                DataTable departmentList = EmployeeBAL.GetDepartmentsBL();
                cmbDepartments.ItemsSource = departmentList.DefaultView;
                cmbDepartments.DisplayMemberPath = departmentList.Columns[1].ColumnName;
                cmbDepartments.SelectedValuePath = departmentList.Columns[0].ColumnName;
            }
            catch (EmployeeException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void Clear()
        {
            txtId.Clear();
            txtName.Clear();
            cmbDesignations.SelectedIndex = -1;
            cmbDepartments.SelectedIndex = -1;
            dgEmployees.DataContext = null;
        }


        private void Window_Loaded_1(object sender, RoutedEventArgs e)
        {
            GetDesignations();
            GetDepartments();
        }



    }
}
