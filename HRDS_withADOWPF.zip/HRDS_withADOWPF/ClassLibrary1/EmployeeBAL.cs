﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;
using EXCEPTIONS;
using DAL;
using System.Data;

namespace BAL

{
    public class EmployeeBAL
    {
        private static bool ValidateEmployee(Employee employee)
        {
            StringBuilder sb = new StringBuilder();
            bool validEmployee = true;
            if (employee.Id <= 0)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine
                    + "Employee Id should be greater than 0.");
            }
            if (employee.Name == string.Empty)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Employee Name can't be empty.");
            }
            if (Convert.ToString(employee.Designation).Length < 1)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "DesignationId must be of 4 digits.");
            }
            if (Convert.ToString(employee.Department).Length < 1)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "DepartmentId must be of 4 digits.");
            }
            if (validEmployee == false)
            {
                throw new EmployeeException(sb.ToString());
            }
            return validEmployee;

        }

        public static bool AddEmployeeBL(Employee employee)
        {
            bool employeeAdded = false;
            try
            {
                if (ValidateEmployee(employee))
                {
                    EmployeeDAL employeeDAL = new EmployeeDAL();
                    employeeAdded = employeeDAL.AddEmployeeDAL(employee);
                    return employeeAdded;
                }
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return employeeAdded;
        }

        public static bool UpdateEmployeeBL(Employee employee)
        {
            bool employeeUpdated = false;
            try
            {
                if (ValidateEmployee(employee))
                {
                    EmployeeDAL employeeDAL = new EmployeeDAL();
                    employeeUpdated = employeeDAL.UpdateEmployeeDAL(employee);
                    return employeeUpdated;
                }
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return employeeUpdated;
        }

        public static bool DeleteEmployeeBL(int employeeId)
        {
            bool employeeDeleted = false;
            try
            {
                if (employeeId > 0)
                {
                    EmployeeDAL employeeDAL = new EmployeeDAL();
                    employeeDeleted = employeeDAL.DeleteEmployeeDAL(employeeId);
                }
                else
                {
                    throw new EmployeeException("Employee Id must be greater than 0.");
                }
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return employeeDeleted;
        }

        public static Employee SearchEmployeeBL(int employeeId)
        {
            Employee employee = null;
            try
            {
                if (employeeId > 0)
                {
                    EmployeeDAL employeeDAL = new EmployeeDAL();
                    employee = employeeDAL.SearchEmployeeDAL(employeeId);
                }
                else
                {
                    throw new EmployeeException("Employee Id must be greater than 0.");
                }
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return employee;
        }

        public static List<Employee> GetAllEmployeeBL()
        {
            List<Employee> employeeList;
            try
            {
                EmployeeDAL employeeDAL = new EmployeeDAL();
                employeeList = employeeDAL.GetAllEmployeesDAL();
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return employeeList;
        }

        public static DataTable GetDesignationsBL()
        {
            DataTable designationList;
            try
            {
                EmployeeDAL employeeDAL = new EmployeeDAL();
                designationList = employeeDAL.GetDesignationsDAL();
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return designationList;
        }

        public static DataTable GetDepartmentsBL()
        {
            DataTable departmentList;
            try
            {
                EmployeeDAL employeeDAL = new EmployeeDAL();
                departmentList = employeeDAL.GetDepartmentsDAL();
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return departmentList;
        }



    }
}
