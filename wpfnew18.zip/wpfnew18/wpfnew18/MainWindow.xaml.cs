﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Data.Entity;

namespace wpfnew18
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        CustomermgmtEntities objCustomermgmtEntities = new CustomermgmtEntities();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnAddEmployee_Click(object sender, RoutedEventArgs e)

        {
            AddEmployee();
        }

        private void BtnUpdateEmployee_Click(object sender, RoutedEventArgs e)
        {
            UpdateEmployee();
        }

        private void BtnDeleteEmployee_Click(object sender, RoutedEventArgs e)
        {
            DeleteEmployee();
        }

        private void BtnSearchEmployee_Click(object sender, RoutedEventArgs e)
        {
            SearchEmployee();
        }

        private void BtnGetEmployees_Click(object sender, RoutedEventArgs e)
        {
            GetEmployees();
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            Clear();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetDesignations();
            GetDepartments();
        }
        public void AddEmployee()
        {
            int id;
            string name;
            int designationId;
            int departmentId;
            //
            id = Convert.ToInt32(txtId.Text);
            name = txtName.Text;
            designationId = Convert.ToInt32(cmbDesignations.SelectedValue.ToString());
            departmentId = Convert.ToInt32(cmbDepartments.SelectedValue.ToString());
            //
            Employee objEmployee = new Employee
            {
                ID = id,
                Name = name,
                Designation = designationId,
                Department = departmentId
            };
            objCustomermgmtEntities.Employees.Add(objEmployee);
            int noOfRowsAffected = objCustomermgmtEntities.SaveChanges();
            if (noOfRowsAffected > 0)
            {
                MessageBox.Show("Data inserted successfully.");
            }
            else
            {
                MessageBox.Show("Data could not be inserted.");
            }

        }

        public void UpdateEmployee()
        {
            int id;
            string name;
            int designationId;
            int departmentId;
            //
            id = Convert.ToInt32(txtId.Text);
            name = txtName.Text;
            designationId = Convert.ToInt32(cmbDesignations.SelectedValue.ToString());
            departmentId = Convert.ToInt32(cmbDepartments.SelectedValue.ToString());
            //
            Employee objEmployee = objCustomermgmtEntities.Employees.Find(id);
            //Employee objEmployee = new Employee();
            objEmployee.ID = id;
            objEmployee.Name = name;
            objEmployee.Designation = designationId;
            objEmployee.Department = departmentId;
            //
            objCustomermgmtEntities.Entry(objEmployee).State = EntityState.Modified;//State is Modified
            int noOfRowsAffected = objCustomermgmtEntities.SaveChanges();//State is Unchanged
            if (noOfRowsAffected > 0)
            {
                MessageBox.Show("Data updated successfully.");
            }
            else
            {
                MessageBox.Show("Data could not be updated.");
            }
        }

        public void DeleteEmployee()
        {
            int id;
            //
            id = Convert.ToInt32(txtId.Text);
            //
            Employee objEmployee = objCustomermgmtEntities.Employees.Find(id);
            objCustomermgmtEntities.Employees.Remove(objEmployee);
            int noOfRowsAffected = objCustomermgmtEntities.SaveChanges();
            if (noOfRowsAffected > 0)
            {
                MessageBox.Show("Data deleted successfully.");
            }
            else
            {
                MessageBox.Show("Data could not be deleted.");
            }
        }

        public void SearchEmployee()
        {
            int id;
            //
            id = Convert.ToInt32(txtId.Text);
            //Option 1:
            /*
            foreach (var objEmployee in objEmployeeMgmtEntities.Employees)
            {
                if(objEmployee.ID == id)
                {
                    txtName.Text = objEmployee.Name;
                    cmbDesignations.SelectedValue = objEmployee.Designation;
                    cmbDepartments.SelectedValue = objEmployee.Department;
                }
            }
            */
            //Option 2:
            Employee objEmployee = objCustomermgmtEntities.Employees.Find(id);
            txtName.Text = objEmployee.Name;
            cmbDesignations.SelectedValue = objEmployee.Designation;
            cmbDepartments.SelectedValue = objEmployee.Department;
            //
        }

        public void GetEmployees()
        {

            var employeesFromDept = from emp in objCustomermgmtEntities.Employees
                                    
                                    select emp;
            /*                       
           var employeesOrdered = from emp in objEmployeeMgmtEntities.Employees
                                  orderby emp.Name ascending
                                  select emp;
                                  */

            //dgvEmployeeDetails.DataSource = objEmployeeMgmtEntities.Employees.ToList();
            //dgvEmployeeDetails.DataSource = employeesOrdered.ToList();
            dgEmployees.ItemsSource = employeesFromDept.ToList();
        }

        public void GetDesignations()
        {
            SqlConnection objCon = new SqlConnection(@"server=ndamssql\sqlilearn;database=Training_19Sep19_Pune;uid=sqluser;pwd=sqluser");
            SqlCommand objCom = new SqlCommand("select * from [46008587].[Designation]", objCon);
            objCon.Open();
            SqlDataReader objDR = objCom.ExecuteReader();
            DataTable objDT = new DataTable();
            objDT.Load(objDR);
            cmbDesignations.ItemsSource = objDT.DefaultView;
            cmbDesignations.DisplayMemberPath = objDT.Columns[1].ColumnName;
            cmbDesignations.SelectedValuePath = objDT.Columns[0].ColumnName;
            objCon.Close();

        }

        public void GetDepartments()
        {
            SqlConnection objCon = new SqlConnection(@"server=ndamssql\sqlilearn;database=Training_19Sep19_Pune;uid=sqluser;pwd=sqluser");
            SqlCommand objCom = new SqlCommand("select * from [46008587].department", objCon);
            objCon.Open();
            SqlDataReader objDR = objCom.ExecuteReader();
            DataTable objDT = new DataTable();
            objDT.Load(objDR);
            cmbDepartments.ItemsSource = objDT.DefaultView;
            cmbDepartments.DisplayMemberPath = objDT.Columns[1].ColumnName;
            cmbDepartments.SelectedValuePath = objDT.Columns[0].ColumnName;
            objCon.Close();
        }

        public void Clear()
        {
            txtId.Text = string.Empty;
            txtName.Clear();
            cmbDesignations.SelectedIndex = -1;
            cmbDepartments.SelectedIndex = -1;
        }
    }
}
